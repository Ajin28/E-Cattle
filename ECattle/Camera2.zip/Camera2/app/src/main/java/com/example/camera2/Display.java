package com.example.camera2;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class Display extends AppCompatActivity {

    ImageView image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        image=findViewById(R.id.imageView);
        Bitmap bitmap= BitmapFactory.decodeFile(getIntent().getStringExtra("imagePath"));
        image.setImageBitmap(bitmap);
    }
}

package com.example.camera2;

import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    String currentImagePath=null;
    private static  final int imageRequest=2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void capturePicture(View view) {
        Intent cameraIntent= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(cameraIntent.resolveActivity(getPackageManager())!=null)
        {
            File imageFile=null;
           try {
              imageFile=getImageFile();
           } catch (IOException e) {
                e.printStackTrace();
           }

            if(imageFile!=null)
            {
                Uri imageUri= FileProvider.getUriForFile(getApplicationContext(),"com.example.android.fileProvide",imageFile);
               cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT,imageUri);
                startActivityForResult(cameraIntent,imageRequest);

            }
        }
    }

    public void displayPicture(View view) {
        Intent displayIntent= new Intent(getApplicationContext(),Display.class);
        displayIntent.putExtra("imagePath",currentImagePath);
        startActivity(displayIntent);
    }



    private File getImageFile()throws IOException {
        //a func that returns a valid file for image

        String timestamp =new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        //to create a unique name for image
        String imagename="jpg_"+timestamp+"_";
        File storageDir= getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File imageFile=File.createTempFile(imagename,".jpg",storageDir);
        currentImagePath=imageFile.getAbsolutePath();
        return imageFile;

    }
}
